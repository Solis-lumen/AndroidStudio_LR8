package com.example.lr8

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.crashlytics.internal.Logger.TAG
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.remoteconfig.ConfigUpdate
import com.google.firebase.remoteconfig.ConfigUpdateListener
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigException
import com.google.firebase.remoteconfig.remoteConfig
import com.google.firebase.remoteconfig.remoteConfigSettings

class MainActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private val db = FirebaseFirestore.getInstance()
    private var isUserInfoVisible = false
    private var isAllUsersVisible = false
    private lateinit var remoteConfig: FirebaseRemoteConfig
//    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        auth = Firebase.auth

        val emailEditText = findViewById<EditText>(R.id.emailEditText)
        val passwordEditText = findViewById<EditText>(R.id.passwordEditText)
        val registerButton = findViewById<Button>(R.id.registerButton)
        val loginButton = findViewById<Button>(R.id.loginButton)
        val logoutButton = findViewById<Button>(R.id.logoutButton)
        val userInfoTextView = findViewById<TextView>(R.id.textView)
        val allUsersTextView = findViewById<TextView>(R.id.textViewForUsers)

        val editTextEmailDelete = findViewById<EditText>(R.id.editTextEmailDelete)
        val buttonDeleteUser = findViewById<Button>(R.id.buttonDeleteUser)

        val editTextEmailUpdate = findViewById<EditText>(R.id.editTextEmailUpdate)
        val editTextNewEmail = findViewById<EditText>(R.id.editTextNewEmail)
        val editTextNewName = findViewById<EditText>(R.id.editTextNewName)
        val buttonUpdateUser = findViewById<Button>(R.id.buttonUpdateUser)

        userInfoTextView.visibility = TextView.GONE
        allUsersTextView.visibility = TextView.GONE

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val crashButton: Button = findViewById(R.id.testCrash)
        crashButton.text = "Test crash"
        crashButton.setOnClickListener{
            throw RuntimeException("Test crash!")   // Forcing a crash
        }

        registerButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            if (email.isNotEmpty() && password.isNotEmpty()) {
                if (password.length < 6) {
                    Toast.makeText(this, "Password must be at least 6 characters long", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                auth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this) { task ->
                        if (task.isSuccessful) {
                            Log.d(TAG, "createUserWithEmail:success")
                            Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show()

                            emailEditText.setText("")
                            passwordEditText.setText("")

                            val user = auth.currentUser
                            user?.let {
                                createUser(it.email ?: "No email", "Unknown name")
                            }
                            updateUI(user, userInfoTextView)
                        } else {
                            Log.w(TAG, "createUserWithEmail:failure", task.exception)
                            Toast.makeText(this, "Registration failed: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
            } else {
                Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show()
            }
        }

        loginButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            if (email.isNotEmpty() && password.isNotEmpty()) {
                if (password.length < 6) {
                    Toast.makeText(this, "Password must be at least 6 characters long", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                auth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this) { task ->
                        if (task.isSuccessful) {
                            Log.d(TAG, "signInWithEmail:success")
                            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show()

                            emailEditText.setText("")
                            passwordEditText.setText("")

                            val user = auth.currentUser
                            updateUI(user, userInfoTextView)
                        } else {
                            Log.w(TAG, "signInWithEmail:failure", task.exception)
                            Toast.makeText(this, "Login failed: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
            } else {
                Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show()
            }
        }

        logoutButton.setOnClickListener {
            auth.signOut() // Вихід із системи
            Toast.makeText(this, "You have been logged out", Toast.LENGTH_SHORT).show()

            // Очищення інформації про користувача з екрану
            findViewById<TextView>(R.id.textView).text = "No user logged in"

            // (Опціонально) Якщо потрібно повернутися до екрана входу/реєстрації:
            val emailEditText = findViewById<EditText>(R.id.emailEditText)
            val passwordEditText = findViewById<EditText>(R.id.passwordEditText)
            emailEditText.setText("")
            passwordEditText.setText("")
        }

        val userInfoButton = findViewById<Button>(R.id.userInfoButton)
        // Handling the userInfoButton click event
        userInfoButton.setOnClickListener {
            if (isUserInfoVisible) {
                // Hide user info and update the button text
                userInfoTextView.visibility = TextView.GONE
                userInfoButton.text = "Show user info"
            } else {
                // Show user info and update the button text
                val user = auth.currentUser
                updateUI(user, userInfoTextView)
                userInfoTextView.visibility = TextView.VISIBLE
                userInfoButton.text = "Hide user info"
            }
            isUserInfoVisible = !isUserInfoVisible
        }

        val nameEditText = findViewById<EditText>(R.id.nameEditText)
        val addUserButton = findViewById<Button>(R.id.addUserButton)
        // Метод для додавання нового користувача в колекцію
        addUserButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val name = nameEditText.text.toString().trim()
            if (email.isNotEmpty() && name.isNotEmpty()) {
                createUser(email, name)
                emailEditText.setText("")
                nameEditText.setText("")
            } else {
                Toast.makeText(this, "Please enter email and name", Toast.LENGTH_SHORT).show()
            }
        }

        val getUserButton = findViewById<Button>(R.id.getUserButton)
        getUserButton.setOnClickListener {
            getUserData(allUsersTextView) // Fetch all users
        }

        buttonUpdateUser.setOnClickListener {
            val email = editTextEmailUpdate.text.toString()
            val newEmail = editTextNewEmail.text.toString().ifEmpty { null }
            val newName = editTextNewName.text.toString().ifEmpty { null }

            if (email.isNotEmpty()) {
                if (newEmail == null && newName == null) {
                    // Обидва поля порожні
                    Toast.makeText(this, "There is nothing to update", Toast.LENGTH_SHORT).show()
                } else {
                    // Внесення змін у разі заповнення одного або обох полів
                    updateUser(email, newEmail, newName)
                    Toast.makeText(this, "User updated successfully", Toast.LENGTH_SHORT).show()

                    editTextEmailUpdate.setText("")
                    editTextNewEmail.setText("")
                    editTextNewName.setText("")
                }
            } else {
                // Поле email порожнє
                Toast.makeText(this, "Please enter the current email!", Toast.LENGTH_SHORT).show()
            }
        }

        buttonDeleteUser.setOnClickListener {
            val email = editTextEmailDelete.text.toString()
            if (email.isNotEmpty()) {
                deleteUser(email)
                editTextEmailDelete.setText("")
            } else {
                Toast.makeText(this, "Please enter an email!", Toast.LENGTH_SHORT).show()
            }
        }

        // Remote Config
        remoteConfig = Firebase.remoteConfig
        val configSettings = remoteConfigSettings {
            minimumFetchIntervalInSeconds = 3
        }

        remoteConfig.setConfigSettingsAsync(configSettings)
        remoteConfig.setDefaultsAsync(R.xml.remote_config_defaults)

        remoteConfig.fetchAndActivate().addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val appTheme = remoteConfig.getString("app_theme")

                if (appTheme == "dark") {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                } else if (appTheme == "light") {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                }

                val value1 = remoteConfig.getString("value_1")
                val value2 = remoteConfig.getString("value_2")
                val value3 = remoteConfig.getString("value_3")
                val value4 = remoteConfig.getString("value_4")
                val value5 = remoteConfig.getString("value_5")

                findViewById<TextView>(R.id.textView1).text = value1
                findViewById<TextView>(R.id.textView2).text = value2
                findViewById<TextView>(R.id.textView3).text = value3
                findViewById<TextView>(R.id.textView4).text = value4
                findViewById<TextView>(R.id.textView5).text = value5
            } else {
                Log.w("RemoteConfig", "Failed to fetch initial config.")
            }
        }

        remoteConfig.addOnConfigUpdateListener(object : ConfigUpdateListener {
            override fun onUpdate(configUpdate: ConfigUpdate) {
                Log.d("RemoteConfig", "Updated keys: ${configUpdate.updatedKeys}")

                remoteConfig.activate().addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Log.d("RemoteConfig", "Config activation successful")

                        runOnUiThread {
                            configUpdate.updatedKeys.forEach { key ->
                                when (key) {
                                    "app_theme" -> {
                                        val appTheme = remoteConfig.getString("app_theme")
                                        if (appTheme == "dark") {
                                            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                                        } else if (appTheme == "light") {
                                            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                                        }
                                    }
                                    "value_1" -> {
                                        val value1 = remoteConfig.getString("value_1")
                                        findViewById<TextView>(R.id.textView1).text = value1
                                    }
                                    "value_2" -> {
                                        val value2 = remoteConfig.getString("value_2")
                                        findViewById<TextView>(R.id.textView2).text = value2
                                    }
                                    "value_3" -> {
                                        val value3 = remoteConfig.getString("value_3")
                                        findViewById<TextView>(R.id.textView3).text = value3
                                    }
                                    "value_4" -> {
                                        val value4 = remoteConfig.getString("value_4")
                                        findViewById<TextView>(R.id.textView4).text = value4
                                    }
                                    "value_5" -> {
                                        val value5 = remoteConfig.getString("value_5")
                                        findViewById<TextView>(R.id.textView5).text = value5
                                    }
                                }
                            }
                        }
                    } else {
                        Log.w("RemoteConfig", "Failed to activate config update.")
                    }
                }
            }

            override fun onError(error: FirebaseRemoteConfigException) {
                Log.e("RemoteConfig", "Error occurred while fetching remote config", error)
            }
        })

//        // Ініціалізація SharedPreferences
//        sharedPreferences = getSharedPreferences("AppPreferences", MODE_PRIVATE)
//
//        // Встановлення теми на основі збереженого стану
//        val isDarkMode = sharedPreferences.getBoolean("isDarkMode", false)
//        AppCompatDelegate.setDefaultNightMode(
//            if (isDarkMode) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
//        )
//
//        setContentView(R.layout.activity_main)
//
//        val changeThemeButton = findViewById<Button>(R.id.changeThemeButton)
//        changeThemeButton.setOnClickListener {
//            // Змінюємо стан теми
//            val isCurrentlyDarkMode = AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES
//            val newMode = if (isCurrentlyDarkMode) {
//                AppCompatDelegate.MODE_NIGHT_NO
//            } else {
//                AppCompatDelegate.MODE_NIGHT_YES
//            }
//
//            // Зберігаємо новий стан теми
//            sharedPreferences.edit().putBoolean("isDarkMode", !isCurrentlyDarkMode).apply()
//
//            // Встановлюємо нову тему
//            AppCompatDelegate.setDefaultNightMode(newMode)
//
//            // Перезапускаємо Activity для застосування теми
//            recreate()
//        }

    }

    public override fun onStart() {
        super.onStart()
    }

    private fun updateUI(user: FirebaseUser?, userInfoTextView: TextView) {
        if (user != null) {
            val email = user.email ?: "Email not available"
            val emailVerified = if (user.isEmailVerified) "Verified" else "Not verified"
            val uid = user.uid

            userInfoTextView.text = """
                User info:
                Email: $email
                Email verified: $emailVerified
                UID: $uid
            """.trimIndent()

            Toast.makeText(this, "Welcome, $email", Toast.LENGTH_SHORT).show()
        } else {
            userInfoTextView.text = "No user logged in"
        }
    }

    fun createUser(email: String, name: String) {
        // Перевірка, чи існує така електронна адреса або ім'я
        db.collection("users")
            .whereEqualTo("email", email)
            .get()
            .addOnSuccessListener { emailQuerySnapshot ->
                if (!emailQuerySnapshot.isEmpty) {
                    Toast.makeText(this, "User with this email already exists!", Toast.LENGTH_SHORT).show()
                } else {
                    // Якщо користувача з такою електронною адресою немає, перевіряємо ім'я
                    db.collection("users")
                        .whereEqualTo("name", name)
                        .get()
                        .addOnSuccessListener { nameQuerySnapshot ->
                            if (!nameQuerySnapshot.isEmpty) {
                                Toast.makeText(this, "User with this name already exists!", Toast.LENGTH_SHORT).show()
                            } else {
                                // Додаємо користувача, якщо електронна адреса та ім'я унікальні
                                val user = hashMapOf(
                                    "email" to email,
                                    "name" to name
                                )

                                db.collection("users")
                                    .add(user)
                                    .addOnSuccessListener { documentReference ->
                                        val generatedId = documentReference.id
                                        Log.d(TAG, "Document added with ID: $generatedId")
                                        Toast.makeText(this, "User added! ID: $generatedId", Toast.LENGTH_SHORT).show()
                                    }
                                    .addOnFailureListener { e ->
                                        Log.w(TAG, "Error adding document", e)
                                        Toast.makeText(this, "Failed to add user", Toast.LENGTH_SHORT).show()
                                    }
                            }
                        }
                        .addOnFailureListener { e ->
                            Log.w(TAG, "Error checking for existing name", e)
                            Toast.makeText(this, "Failed to check user name", Toast.LENGTH_SHORT).show()
                        }
                }
            }
            .addOnFailureListener { e ->
                Log.w(TAG, "Error checking for existing email", e)
                Toast.makeText(this, "Failed to check user email", Toast.LENGTH_SHORT).show()
            }
    }


//    Метод для оновлення даних користувача
    fun updateUser(email: String, newEmail: String? = null, newName: String? = null) {
        // Знаходимо користувача за email
        db.collection("users")
            .whereEqualTo("email", email)
            .get()
            .addOnSuccessListener { querySnapshot ->
                if (!querySnapshot.isEmpty) {
                    for (document in querySnapshot.documents) {
                        val userId = document.id
                        val updates = hashMapOf<String, Any>()

                        if (newEmail != null) updates["email"] = newEmail
                        if (newName != null) updates["name"] = newName

                        if (updates.isNotEmpty()) {
                            db.collection("users").document(userId)
                                .update(updates)
                                .addOnSuccessListener {
                                    Log.d(TAG, "User with email $email successfully updated!")
                                    Toast.makeText(this, "User updated!", Toast.LENGTH_SHORT).show()
                                }
                                .addOnFailureListener { e ->
                                    Log.w(TAG, "Error updating user document", e)
                                    Toast.makeText(this, "Error updating user", Toast.LENGTH_SHORT).show()
                                }
                        } else {
                            Toast.makeText(this, "No updates provided!", Toast.LENGTH_SHORT).show()
                        }
                    }
                } else {
                    Toast.makeText(this, "No user found with this email!", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { e ->
                Log.w(TAG, "Error finding user for update", e)
                Toast.makeText(this, "Error finding user", Toast.LENGTH_SHORT).show()
            }
    }

// Метод для видалення користувача
    fun deleteUser(email: String) {
        // Знаходимо документ користувача за email
        db.collection("users")
            .whereEqualTo("email", email)
            .get()
            .addOnSuccessListener { querySnapshot ->
                if (!querySnapshot.isEmpty) {
                    for (document in querySnapshot.documents) {
                        val userId = document.id
                        db.collection("users").document(userId)
                            .delete()
                            .addOnSuccessListener {
                                Log.d(TAG, "User with email $email successfully deleted!")
                                Toast.makeText(this, "User deleted!", Toast.LENGTH_SHORT).show()
                            }
                            .addOnFailureListener { e ->
                                Log.w(TAG, "Error deleting user document", e)
                                Toast.makeText(this, "Error deleting user", Toast.LENGTH_SHORT).show()
                            }
                    }
                } else {
                    Toast.makeText(this, "No user found with this email!", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { e ->
                Log.w(TAG, "Error finding user for deletion", e)
                Toast.makeText(this, "Error finding user", Toast.LENGTH_SHORT).show()
            }
    }

    // Метод для отримання всіх користувачів
    fun getUserData(allUsersTextView: TextView) {
        if (isAllUsersVisible) {
            // Якщо список уже відображається, приховуємо його та змінюємо текст кнопки
            allUsersTextView.visibility = TextView.GONE
            findViewById<Button>(R.id.getUserButton).text = "Show all users"
        } else {
            db.collection("users")
                .get()
                .addOnSuccessListener { result ->
                    val userList = StringBuilder()
                    for (document in result) {
                        val email = document.getString("email") ?: "No email"
                        val name = document.getString("name") ?: "No name"
                        userList.append("User: $name, Email: $email\n")
                    }
                    allUsersTextView.text = userList.toString()
                    allUsersTextView.visibility = TextView.VISIBLE
                    findViewById<Button>(R.id.getUserButton).text = "Hide all users"
                }
                .addOnFailureListener { exception ->
                    Log.w(TAG, "Error getting documents.", exception)
                    Toast.makeText(this, "Error fetching data.", Toast.LENGTH_SHORT).show()
                }
        }
        isAllUsersVisible = !isAllUsersVisible
    }
}